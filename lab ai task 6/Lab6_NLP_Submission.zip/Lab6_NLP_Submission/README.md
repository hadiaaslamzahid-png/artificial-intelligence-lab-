# Lab 6 — NLP Fundamentals

This folder contains the three lab tasks: tokenization and FAQ retrieval, text chunking, and document retrieval evaluation.

## Setup
Use Python 3.10 or newer.

```bash
python -m venv .venv
```

Windows PowerShell:
```powershell
.venv\Scripts\Activate.ps1
```

Install packages:
```bash
python -m pip install -r requirements.txt
```

## Run the tasks
```bash
python task1_tokens.py
python task1_chatbot_check.py
python guided_chatbot.py
python task2_chunks.py
python task3_retrieval.py --backend tfidf
```

For actual sentence embeddings:
```bash
python -m pip install sentence-transformers
python task3_retrieval.py --backend embedding
```

To compare both retrieval backends:
```bash
python task3_retrieval.py --backend both
```

The first embedding run downloads `sentence-transformers/all-MiniLM-L6-v2` and needs internet access. It runs on CPU. TF-IDF works without that model.

## Files
- `task1_tokens.py`: six tokenization examples.
- `guided_chatbot.py`: FAQ assistant with source labels and confirmation for non-exact matches.
- `task2_chunks.py`: 40-word windows, overlap, sentence-aware chunks, offsets and tests.
- `task3_retrieval.py`: evaluation for three chunking strategies and two retrieval backends.
- `corpus.json`, `queries.json`: synthetic practice data and labeled queries.
- `retrieval_log.csv`: created when Task 3 is run.
- `Lab6_Report.docx`: short lab report.

The handbook, support, and workplace examples are synthetic. They are not actual university or company policies.
