import csv
import json
import time
import argparse
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from task2_chunks import make_chunks


def evaluate(score_rows, chunks, items):
    hits, reciprocal_ranks = [], []

    for scores, query in zip(score_rows, items):
        if query["doc"] is None:
            continue

        top_indices = np.argsort(-scores, kind="stable")[:3]
        relevant_ranks = [
            rank for rank, index in enumerate(top_indices, 1)
            if chunks[index]["doc"] == query["doc"]
            and query["evidence"] in chunks[index]["text"]
        ]
        hits.append(bool(relevant_ranks))
        reciprocal_ranks.append(
            1 / relevant_ranks[0] if relevant_ranks else 0
        )

    if not hits:
        return None, None
    return float(np.mean(hits)), float(np.mean(reciprocal_ranks))


def run_tfidf(chunks, questions):
    texts = [chunk["text"] for chunk in chunks]
    started = time.perf_counter()
    vectorizer = TfidfVectorizer()
    chunk_vectors = vectorizer.fit_transform(texts)
    question_vectors = vectorizer.transform(questions)
    encoding_seconds = time.perf_counter() - started

    started = time.perf_counter()
    scores = (question_vectors @ chunk_vectors.T).toarray()
    search_seconds = time.perf_counter() - started
    return scores, encoding_seconds, search_seconds


def run_embeddings(chunks, questions):
    from sentence_transformers import SentenceTransformer

    started = time.perf_counter()
    model = SentenceTransformer(
        "sentence-transformers/all-MiniLM-L6-v2", device="cpu"
    )
    model_load_seconds = time.perf_counter() - started

    all_text = [chunk["text"] for chunk in chunks] + questions
    lengths = [
        len(model.tokenizer(text, truncation=False)["input_ids"])
        for text in all_text
    ]
    if max(lengths) > model.max_seq_length:
        raise ValueError("An input exceeds the model limit. Rechunk it.")

    started = time.perf_counter()
    chunk_vectors = model.encode(
        [chunk["text"] for chunk in chunks],
        normalize_embeddings=True
    )
    question_vectors = model.encode(
        questions, normalize_embeddings=True
    )
    encoding_seconds = time.perf_counter() - started

    started = time.perf_counter()
    scores = question_vectors @ chunk_vectors.T
    search_seconds = time.perf_counter() - started
    return scores, encoding_seconds, search_seconds, model_load_seconds


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--backend", choices=["tfidf", "embedding", "both"],
        default="tfidf"
    )
    args = parser.parse_args()

    with open("corpus.json", encoding="utf-8") as file:
        documents = json.load(file)
    with open("queries.json", encoding="utf-8") as file:
        items = json.load(file)

    for query in items:
        if query["doc"] is not None:
            assert query["evidence"] in documents[query["doc"]]

    questions = [item["query"] for item in items]
    backends = ["tfidf", "embedding"] if args.backend == "both" else [args.backend]
    log_rows = []

    for strategy in ["0", "10", "sentence"]:
        chunks = make_chunks(documents, strategy)
        for backend in backends:
            if backend == "tfidf":
                scores, encode_time, search_time = run_tfidf(chunks, questions)
                model_load_time = ""
            else:
                scores, encode_time, search_time, model_load_time = run_embeddings(
                    chunks, questions
                )

            print(
                f"\nStrategy={strategy}; backend={backend}; "
                f"chunks={len(chunks)}; encode={encode_time:.4f}s; "
                f"search={search_time:.4f}s; model_load={model_load_time}"
            )

            for split in ["dev", "test"]:
                selected = [
                    index for index, item in enumerate(items)
                    if item["split"] == split and item["doc"] is not None
                ]
                hit, mrr = evaluate(
                    scores[selected], chunks, [items[index] for index in selected]
                )
                print(f"{split}: Hit@3={hit:.3f}; MRR@3={mrr:.3f}")

            for row, item in zip(scores, items):
                top = np.argsort(-row, kind="stable")[:3]
                for rank, index in enumerate(top, 1):
                    chunk = chunks[index]
                    log_rows.append({
                        "strategy": strategy,
                        "backend": backend,
                        "query": item["query"],
                        "split": item["split"],
                        "answerable": item["doc"] is not None,
                        "rank": rank,
                        "score": round(float(row[index]), 6),
                        "chunk_id": chunk["id"],
                        "document": chunk["doc"],
                        "start": chunk["start"],
                        "end": chunk["end"],
                        "text": chunk["text"]
                    })

    with open("retrieval_log.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(log_rows[0]))
        writer.writeheader()
        writer.writerows(log_rows)
    print("\nSaved top-three results to retrieval_log.csv.")
    print("Unanswerable questions are logged separately; they have no relevant evidence.")


if __name__ == "__main__":
    main()
